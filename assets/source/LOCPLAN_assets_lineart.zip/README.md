# LOCPLAN — Blockbench 設備資產（灰階版＋技術線稿版）

兩套外觀、同一套幾何，各 26 件：工廠設備 13 件＋生活場景 13 件。

## 重要：檔案格式已修正

先前版本在 Blockbench 開啟顯示「無效數據」，原因是使用了舊的頂層 `format_version: 4.2`。现已全部改為 **Blockbench 5.0 / free**（`meta.format_version = "5.0"`、`model_format = "free"`、`box_uv = false`），並比對本機可正常開啟的真實 `.bbmodel` 欄位結構。`outliner` 改為群組物件＋`children` 元素 UUID；貼圖以 base64 內嵌。**兩套檔都已修正。**

另外，灰階版原本把面設為 `texture: null`，Blockbench 會把這些面當成透明，只顯示線框。现已改為指定 16×16 實心灰貼圖、每面 UV 填滿整張貼圖，Blockbench 會顯示實心灰面。HTML 仍不讀 UV，不受影響。

## 交付內容

| 路徑 | 說明 |
|---|---|
| `LOCPLAN_assets.zip` | 灰階版原檔：26 個 `.bbmodel` + `gray.png` + 兩份尺寸表 + README |
| `LOCPLAN_assets_lineart.zip` | 線稿版原檔：26 個 `_lineart.bbmodel` + `lineart.png` + 兩份尺寸表 + README |
| `models/` | 灰階版：16×16 實心灰貼圖、全格 UV，Blockbench 顯示實心灰面 |
| `models_lineart/` | 線稿版：32×32 白底＋2px 深灰邊框貼圖，每個面 UV 填滿整張貼圖 |
| `renders/overview.png` | 灰階版 26 件總覽；另有 `overview_batch1.png`、`overview_batch2.png` |
| `renders/overview_lineart.png` | 線稿版 26 件總覽 |
| `renders/*_views.png` | 每件四視圖（斜視／前／側／上） |
| `dimensions.csv` / `dimensions_batch2.csv` | 兩批建議尺寸、操作側、交接高度（UTF-8 BOM） |
| `build_assets.py` / `build_batch2.py` / `build_lineart.py` | 三套產生器 |
| `verify.py` / `check_float.py` / `package.py` / `make_overview.py` | 驗證、懸空偵測、打包、總覽 |

`verify.py` 一次檢查兩套共 **52 個檔案**：目前 **ALL PASS**。檢查項目包含 5.0 格式、無旋轉 Cube、原點在地面中央、10–100 Cube、貼圖內嵌、結構引用完整，以及**連通性**：每件的所有 Cube 都必須與主體接觸，沒有懸空部件。`check_float.py` 可單獨列出懸空部件（`float_report.txt`）。

## 線稿版美術規格

- 參考圖的白底黑線技術繪圖風格。
- 貼圖 `lineart.png` 為 32×32：白色填充、2px 深灰（#262626）外框；已 base64 內嵌進每個 `.bbmodel`。
- 每個 Cube 的六個面 UV 皆為 `[0,0,32,32]`，因此每面都有一圈邊線。
- resolution 設為 32×32；原始灰階版為 16×16。
- 幾何、尺寸、原點、Pivot 與灰階版**完全一致**，只差材質，可直接替換。
- 提醒：現行 HTML 灰階渲染不讀 UV，線稿檔主要供 Blockbench 檢視／未來完整 3D 使用；目前 HTML 请用 `models/` 灰階版。

## 模型公約（兩套共用）

- 單位：1 model unit = 0.10 m；HTML 讀取包圍盒映射實際尺寸，不強制 16³。
- 原點：X/Z 位於包圍盒中心，Y=0 在地面；前方 +Z（south）。
- 全部為未旋轉 Cube；無 Mesh、無旋轉群組、無骨架動畫。
- 每件 10–25 Cube，落在建議的 10–100 內。
- 可拆換部件用獨立命名群組（`frame`、`shelves`、`load`、`doors`、`belt`、`robot`、`fence`、`equipment`、`glass` 等）。
- 桌椅拆為 `cafe_table`、`cafe_chair` 兩個獨立模型。
- 尺寸表的數值是示範預設值而非實測規格；`clearance_m` 刻意留空不猜測。

## 第一批（工廠，13 件）

pallet_rack_small / large、cnc_small / cnc_large、workbench_straight / workbench_double、conveyor_straight、robot_cell_small、rack_low / rack_high、inspect_pack_bench、pallet_jack、standing_person。

## 第二批（生活場景，13 件）

cashier_counter、espresso_machine、bar_counter、prep_table、wash_station、pickup_shelf、cafe_table、cafe_chair、refrigerator；wall_segment、door、window、column。

住家／教室與輸送帶彎角尚未製作，可後續擴充。
